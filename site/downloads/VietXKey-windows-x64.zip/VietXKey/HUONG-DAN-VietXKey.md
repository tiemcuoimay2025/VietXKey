# VietXKey — nền sáng / tối, điểm nhấn xanh rêu

Bản tùy biến từ VietFlow v0.1.4, dành cho Windows x64.

## Giao diện mới

Logo phím V xanh rêu, nền chuyển sắc sáng / tối. Nhấn **Nền sáng / Nền tối**
trên đầu bảng điều khiển; ứng dụng lưu lựa chọn cho lần mở sau.

Trang giới thiệu: https://tiemcuoimay2025.github.io/VietXKey/
Mã nguồn: https://github.com/tiemcuoimay2025/VietXKey

## Chạy ứng dụng

Giải nén `VietXKey-final-x64.zip`, rồi mở `VietXKey.exe`. Giữ `vietxkey_tsf.dll`
cùng thư mục. Mở cài đặt từ biểu tượng ở khay hệ thống để xem giao diện.

Mở EXE thông thường (kể cả lần đầu) sẽ hiện bảng điều khiển và biểu tượng tray.
Chọn **Chạy với quyền quản trị** sẽ mở lại bảng điều khiển sau khi anh đồng ý UAC;
hủy UAC thì cửa sổ cũ vẫn giữ nguyên.

Để chỉ mở cài đặt, chạy `VietXKey.exe --settings`. Các thiết lập được lưu tự
động; nút “Lưu & đóng” đóng cửa sổ cài đặt.

Bản chữ lớn tăng cỡ chữ chính từ 16 lên 20 px và nâng các nhãn nhỏ lên tối
thiểu 14 px, tự co giãn theo DPI của Windows. Sidebar và thẻ cài đặt đã được
nới khoảng cách; ở cửa sổ thấp, có thể cuộn danh sách điều hướng bên trái.
Thoát bản VietXKey đang chạy trước khi mở `VietXKey.exe` từ gói mới.

## Tự mở bảng điều khiển khi vào Windows

Trong **Tổng quan → Sẵn sàng mỗi ngày**, bật **Khởi động cùng Windows** và
**Mở bảng điều khiển khi khởi động**. Công tắc thứ hai mặc định bật; nếu tắt,
VietXKey chỉ chạy ở khay hệ thống khi đăng nhập.

Sau khi cập nhật, mở bản VietXKey mới một lần để ứng dụng cập nhật đường dẫn
khởi động Windows. Tùy chọn này áp dụng từ lần đăng nhập Windows kế tiếp.

Bản sửa lỗi gõ: Ctrl+Shift của VietXKey chỉ chuyển Việt/Anh khi thả tổ hợp và
không bấm thêm phím khác. Từ tiếng Anh hoặc từ gõ sai không còn tắt hẳn tiếng
Việt; có thể gõ tiếp từ tiếng Việt sau dấu cách. Chi tiết kiểm thử nằm trong
`docs/INPUT_FIXES.md` của gói mã nguồn.

Nếu ENG/VIE trên thanh tác vụ Windows cũng đổi thì cần phân biệt với phím tắt
đổi bàn phím của chính Windows. Ở trạng thái “Do Windows quản lý”, dùng
Win+Space để chọn lại bàn phím VietXKey. Bản sửa này không thay đổi cấu hình
ngôn ngữ của Windows.

## Sửa lỗi Windows và Đà Nẵng

Bản hiện tại giữ nguyên thao tác thoát dấu Telex: `WWindows` cho ra `Windows`
và không thêm lại W khi bấm dấu cách hoặc dấu câu. `DDaf Nawngx` cho ra
`Đà Nẵng`; hai phím D hoa không còn bị hiểu nhầm thành tên viết tắt tiếng Anh.
Các cách gõ này không làm tắt tiếng Việt ở từ kế tiếp.

Lần cập nhật này thay đổi cả `VietXKey.exe` và `vietxkey_tsf.dll`. Thoát
VietXKey, giải nén gói mới và thay cả hai file tại thư mục đang dùng. Nếu DLL
đang được ứng dụng khác giữ, đóng ứng dụng đó; không cần ép xóa file đang dùng.
Sau khi thay file, mở lại VietXKey và các ứng dụng soạn thảo. Với chế độ bộ gõ
do Windows quản lý, cần mở lại ứng dụng đang nạp DLL để dùng mã mới.

## Gõ zề và phụ âm ngoại lai có dấu

Trong **Gõ tiếng Việt → Ngoại lai & tiếng Anh**, giữ `z` trong ô **Phụ âm ngoại lai**
(mặc định `fjwz`). Gõ Telex `zeef` để được **zề**, `Zeef` để được **Zề**.
VNI dùng `ze62`. Từ có dấu được giữ nguyên khi bấm dấu cách hoặc dấu câu.

Danh sách này giờ cho phép phụ âm đứng đầu từ có dấu. Khi bật kiểm tra chính
tả, xóa hết danh sách để chỉ dùng phụ âm tiếng Việt chuẩn. Các từ tiếng
Anh trong danh sách giữ nguyên vẫn được bảo vệ. Các quy tắc W/WW của kiểu
gõ Telex đang chọn được giữ nguyên.

Cập nhật **cả EXE và DLL** cùng gói, rồi mở lại ứng dụng soạn thảo đang dùng.
Bản này cũng bao gồm các bản sửa Windows/Đà Nẵng và tự mở bảng điều khiển.

## Gõ trên thanh địa chỉ Comet / Chromium

Bản này sửa trường hợp phần gợi ý trên thanh địa chỉ làm `DDaf` thành `DĐà`.
Đã bổ sung bước xóa chữ cũ trước khi chèn chữ có dấu để tránh giữ đuôi
`o`, `ang` hoặc gợi ý URL trong thanh địa chỉ và ô nhập trang web.
Trong **Gõ tiếng Việt**, để **Cách gửi phím: Tự động** và **Bảng mã: Unicode**.
Cách thay chữ tương thích được áp dụng tự động cho Comet, Chrome, Chromium,
Edge, Brave, Vivaldi và Opera khi dùng chế độ gửi phím thông thường.

Bản mới vẫn giữ bản sửa Comet đã được anh xác nhận. Lần cập nhật giao diện
và tên file này cần giải nén toàn bộ gói để có đúng cặp EXE/DLL mới nhất.
Các chế độ gửi phím chọn thủ công được giữ nguyên.

## Mã nguồn và nguồn gốc

`VietXKey-source.zip` chứa mã nguồn đã sửa cùng các thư viện cần để build.
Dùng `scripts/build-vietxkey.ps1` để tạo bản portable x64 mang tên VietXKey.
Tài liệu thay đổi nằm ở `docs/UI_MOSS.md`; bản vá nằm trong `VietXKey.patch`.

Tên hiển thị, tiêu đề cửa sổ, menu khay hệ thống, thông tin sản phẩm Windows
và tên file phân phối đã dùng VietXKey. Tên ABI và IPC bên trong được giữ
để tương thích bộ gõ hiện có; các file cấu hình và DLL đã chuyển sang vietxkey. Chưa tạo bộ cài MSI mang tên mới.

VietXKey kế thừa VietFlow và thuật toán gõ UniKey. Phần Giới thiệu ghi tác giả
dự án gốc VietFlow Team và “Fix lỗi và phát triển thêm bởi Minh Tâm Đoàn.”
Các nút liên kết, mục cập nhật và phần ủng hộ dự án gốc đã được bỏ.
Nút **Ủng hộ tác giả** mới nằm trong **Giới thiệu**, mở đúng mã QR anh cung cấp.
Giấy phép GPLv3 và các giấy phép font đi kèm bản portable và mã nguồn.

Nguồn gốc: https://github.com/KienPC1234/VietFlow

## Tên file và giao diện mới

- Nền ứng dụng đen xám; nút, chữ nhấn và hình trang trí giữ màu xanh rêu.
- Cấu hình: `vietxkey_config.json`; sao lưu: `vietxkey_config.json.bak`.
- DLL đi kèm: `vietxkey_tsf.dll`. Nhật ký chẩn đoán (khi bật): `vietxkey_tsf.log`.
- Ở chế độ cài đặt, thư mục cấu hình mới là `%ProgramData%\VietXKey` hoặc `%APPDATA%\VietXKey`.
- Bản mới tự đọc cấu hình `vietflow_config.json` hoặc bản `.bak` còn hợp lệ khi
  chưa có cấu hình tên mới. Giữ lại file cấu hình cũ trong lúc cập nhật để tự chuyển
  thiết lập. File cũ được giữ nguyên để dự phòng; các lần lưu tiếp theo dùng tên mới.
- Thoát VietXKey trước khi giải nén toàn bộ gói mới. Nếu đang dùng TSF đã đăng ký,
  mở phần TSF và chọn **Cài lại** sau cập nhật để Windows dùng DLL tên mới, rồi
  đóng/mở lại ứng dụng đang nhập. Không xóa DLL cũ đang bị ứng dụng khác giữ.

## Gõ tắt mặc định và ủng hộ tác giả

- Mẫu gõ tắt mới: `vxk` → `VietXKey`. Bật tính năng **Gõ tắt** để sử dụng.
- Mẫu cũ `vf` → `VietFlow` được tự chuyển khi đọc cấu hình; các gõ tắt tùy chỉnh
  và mẫu đã xóa được giữ nguyên. Nếu `vxk` đã có nội dung riêng, nội dung đó được giữ.
- Trong **Giới thiệu**, nhấn **Ủng hộ tác giả** để hiện mã QR; nhấn **Đóng**, dấu X
  hoặc Esc để đóng. QR được nhúng nguyên ảnh trong EXE, không cần file ảnh đi kèm.
- Tùy chọn **Mở bảng điều khiển khi khởi động** chỉ áp dụng khi đăng nhập Windows.
  Nó không làm ẩn bảng điều khiển khi anh tự mở EXE hay chạy lại bằng quyền quản trị.

## Giữ dấu khi gõ òh / zô

- Telex `ofh` hoặc `ohf` → **òh**; `zoo` → **zô**. Bấm cách, Enter, Tab hoặc
  dấu câu không còn trả lại các phím gốc. Giữ `z` trong mục **Phụ âm ngoại lai**.
- Đã sửa thêm khác biệt chốt từ giữa hai chế độ gõ, gồm các trường hợp `test`,
  `hix` và phím lặp để hủy dấu. Các từ tiếng Anh như `zoom`, `zero`, `Windows`,
  `file`, `join` tiếp tục được giữ đúng.
- Nếu muốn giữ một từ trùng tiếng Anh (ví dụ `zoo`) theo nguyên phím gõ,
  thêm nó tại **Gõ tiếng Việt → Ngoại lai & tiếng Anh → Từ tiếng Anh giữ nguyên**.
- Bản này thay đổi lõi ở cả EXE và DLL. Cập nhật cả hai file rồi mở lại các ứng dụng
  đang nhập để chúng sử dụng đúng bản mới. Không cần đặt lại cấu hình.

## Bật giữ dấu khi viết không chuẩn chính tả

Vào **Gõ tiếng Việt → Dấu tiếng Việt**, bật **Giữ dấu khi viết không chuẩn chính tả**.
Ứng dụng tự lưu. Tùy chọn mặc định tắt, độc lập với **Đặt dấu tự do**.

Khi bật, chữ đã có dấu được ưu tiên giữ khi anh viết từ lóng hoặc cách viết riêng,
kể cả khi bấm cách, Enter hay Tab. Ví dụ `cafp` / `capf` đều thành **càp**.
Từ tiếng Anh dễ nhầm như `of` có thể thành **ò**, `test` có thể thành **tét**.
Nếu không phù hợp, tắt tùy chọn hoặc chuyển sang chế độ tiếng Anh.
Danh sách **Từ tiếng Anh giữ nguyên** được ưu tiên trong chế độ gõ thông thường;
TSF hiện dùng danh sách có sẵn trong lõi, chưa nhận danh sách tùy chỉnh từ giao diện.
Các bản sửa **òh / zô** trước đó vẫn hoạt động khi công tắc mới tắt.

Lần này cần cập nhật **cả EXE và DLL**, rồi đóng/mở lại ứng dụng đang gõ để nhận
thiết lập TSF mới. Các thiết lập khác được giữ nguyên.
